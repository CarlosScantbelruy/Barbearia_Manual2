#!/bin/bash

# Instalar dependências
pnpm install

# Iniciar o servidor Node.js
node server.js
